1. npm install
2. npx sequelize-cli db:create
3. npx sequelize-cli db:migrate
4. npx sequelize-cli db:seed:all

ENDPOINT
- http://localhost:3000/
- http://localhost:3000/movies
- http://localhost:3000/users
- http://localhost:3000/upload